﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LargestCityAndCapital
{
    public class RootObjectList
    {
        public RestResponseList RestResponse { get; set; }
    }
}
