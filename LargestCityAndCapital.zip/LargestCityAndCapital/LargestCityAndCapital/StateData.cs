﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using System.Runtime.Serialization.Json;

namespace LargestCityAndCapital
{
    public class StateData
    {
        public RootObject GetStateDataByAbbreviation(string state)
        {
            if (string.IsNullOrEmpty(state)) return null;
            string stateQuery = $"http://services.groupkt.com/state/get/USA/{state}";
            RootObject rootObject = null;

            using (var webClient = new WebClient())
            {
                webClient.Headers.Add("Content-Type:application/json");
                webClient.Headers.Add("Accept:application/json");
                var resultState = webClient.DownloadString(stateQuery);

                using (var ms = new MemoryStream(Encoding.Unicode.GetBytes(resultState)))
                {
                    DataContractJsonSerializer deserializer = new DataContractJsonSerializer(typeof(RootObject));
                    rootObject = (RootObject)deserializer.ReadObject(ms);
                }
            }
            return rootObject;
        }
        public RootObjectList GetStateData(string state)
        {
            if (string.IsNullOrEmpty(state)) return null;
            string stateQuery = $"http://services.groupkt.com/state/search/USA?text={state}";
            RootObjectList rootObject = null;

            using (var webClient = new WebClient())
            {
                webClient.Headers.Add("Content-Type:application/json");
                webClient.Headers.Add("Accept:application/json");
                var resultState = webClient.DownloadString(stateQuery);

                using (var ms = new MemoryStream(Encoding.Unicode.GetBytes(resultState)))
                {
                    DataContractJsonSerializer deserializer = new DataContractJsonSerializer(typeof(RootObjectList));
                    rootObject = (RootObjectList)deserializer.ReadObject(ms);
                }
            }
            return rootObject;
        }
    }
}
