﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using System.Runtime.Serialization.Json;

namespace LargestCityAndCapital
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            do
            {
                string capital = string.Empty;
                string largest_city = string.Empty;
                string message = string.Empty;

                Console.WriteLine("Please enter state name or state abbreviation. Enter EXIT to exit the Program.");
                input = Console.ReadLine().ToUpper();
                RootObject returnData = null;
                RootObjectList returnData2 = null;

                if (!string.IsNullOrEmpty(input) && input != "EXIT")
                {
                    var stateData = new StateData();
                    if (input.Length == 2)
                    {
                        returnData = stateData.GetStateDataByAbbreviation(input);
                        if (returnData.RestResponse.result == null)
                        {
                            message = returnData.RestResponse.messages[0];
                        }
                        capital = returnData.RestResponse.result?.capital;
                        largest_city = returnData.RestResponse.result?.largest_city;

                    }
                    else
                    {
                        returnData2 = stateData.GetStateData(input);
                        if (!returnData2.RestResponse.result.Any())
                        {
                            message = returnData2.RestResponse.messages[0];
                        }
                        else
                        {
                            capital = returnData2.RestResponse.result[0]?.capital;
                            largest_city = returnData2.RestResponse.result[0]?.largest_city;
                        }
                    }
                    if (!string.IsNullOrEmpty(message))
                    {
                        Console.WriteLine(message);
                    }
                    else
                    {
                        Console.WriteLine($"capital:{capital}");
                        Console.WriteLine($"largest_city:{largest_city}");
                    }
                }
            } while (input != "EXIT");
        }
        //private RootObject GetStateDataByAbbreviation(string state)
        //{
        //    string stateQuery = $"http://services.groupkt.com/state/get/USA/{state}";
        //    RootObject rootObject = null;

        //    using (var webClient = new WebClient())
        //    {
        //        webClient.Headers.Add("Content-Type:application/json");
        //        webClient.Headers.Add("Accept:application/json");
        //        var resultState = webClient.DownloadString(stateQuery);
        //        //Console.WriteLine(Environment.NewLine + resultState);

        //        using (var ms = new MemoryStream(Encoding.Unicode.GetBytes(resultState)))
        //        {
        //            DataContractJsonSerializer deserializer = new DataContractJsonSerializer(typeof(RootObject));
        //            rootObject = (RootObject)deserializer.ReadObject(ms);
        //            //Console.WriteLine(rootObject.RestResponse.result.country);
        //        }
        //    }
        //    return rootObject;
        //}
        //private RootObjectList GetStateData(string state)
        //{
        //    string stateQuery = $"http://services.groupkt.com/state/search/USA?text={state}";
        //    RootObjectList rootObject = null;

        //    using (var webClient = new WebClient())
        //    {
        //        webClient.Headers.Add("Content-Type:application/json");
        //        webClient.Headers.Add("Accept:application/json");
        //        var resultState = webClient.DownloadString(stateQuery);
        //        //Console.WriteLine(Environment.NewLine + resultState);

        //        using (var ms = new MemoryStream(Encoding.Unicode.GetBytes(resultState)))
        //        {
        //            DataContractJsonSerializer deserializer = new DataContractJsonSerializer(typeof(RootObjectList));
        //            rootObject = (RootObjectList)deserializer.ReadObject(ms);
        //        }
        //    }
        //    return rootObject;
        //}
    }
}
