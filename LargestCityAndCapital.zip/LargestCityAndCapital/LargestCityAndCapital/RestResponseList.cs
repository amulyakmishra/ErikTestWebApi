﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LargestCityAndCapital
{
    public class RestResponseList
    {
        public List<string> messages { get; set; }
        public List<Result> result { get; set; }
    }
}
