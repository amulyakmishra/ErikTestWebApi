﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LargestCityAndCapital.Tests
{
    [TestClass]
    public class GetStateDataByAbbreviationTest
    {
        [TestMethod, TestCategory("StateCapitalAndLargestCity"), Description("Get StateCapital And LargestCity")]
        public void GetStateDataByAbbreviationTest_EmptyStateReturnNull()
        {
            //Arrange
            var stateData = new StateData();

            //Act
            var returnData = stateData.GetStateDataByAbbreviation("");
            //Assert
            Assert.IsTrue(returnData == null);
        }
        [TestMethod, TestCategory("StateCapitalAndLargestCity"), Description("Get StateCapital And LargestCity")]
        public void GetStateDataByAbbreviationTest_ValidState()
        {
            //Arrange
            var stateData = new StateData();

            //Act
            var returnData = stateData.GetStateDataByAbbreviation("NJ");
            //Assert
            Assert.AreEqual(returnData.RestResponse.result.capital, "Trenton");
            Assert.AreEqual(returnData.RestResponse.result.largest_city, "Newark");
        }
    }
}

