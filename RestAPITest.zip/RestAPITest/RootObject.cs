﻿namespace RestAPITest
{
    public class RootObject
    {
        public RestResponse RestResponse { get; set; }
    }
}
