﻿using System;
using System.Linq;


namespace RestAPITest
{
    class Program
    {
        static void Main(string[] args)
        {

            string input;

            do
            {
                Console.WriteLine("Please enter state name or state abbreviation. Enter EXIT to exit the Program.");
                input = Console.ReadLine().ToUpper();
                RootObject returnData = null;


                if (!string.IsNullOrEmpty(input) && input != "EXIT")
                {
                    var state = new State();
                    returnData = state.GetStateData(input);

                    var returnStateData = returnData.RestResponse.result.Where(r => r.abbr.ToUpper() == input);
                    returnStateData = returnStateData.Any() ? returnStateData : returnData.RestResponse.result.Where(r => r.name.ToUpper() == input);

                    if (returnStateData.Any())
                    {
                        foreach (var item in returnStateData)
                        {
                            Console.WriteLine($"capital:{item.capital}");
                            Console.WriteLine($"largest_city:{item.largest_city}");
                        }
                    }
                    else
                    {
                        Console.WriteLine("No record found.");
                    }
                }
            } while (input != "EXIT");
        }
       
    }
}
