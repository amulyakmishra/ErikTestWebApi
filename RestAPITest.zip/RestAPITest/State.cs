﻿using System.Text;
using System.Net;
using System.IO;
using System.Runtime.Serialization.Json;

namespace RestAPITest
{
    public class State
    {
        public RootObject GetStateData(string state)
        {
            string stateQuery = $"http://services.groupkt.com/state/get/USA/all";
            RootObject rootObject = null;

            using (var webClient = new WebClient())
            {
                webClient.Headers.Add("Content-Type:application/json");
                webClient.Headers.Add("Accept:application/json");
                var resultState = webClient.DownloadString(stateQuery);

                using (var ms = new MemoryStream(Encoding.Unicode.GetBytes(resultState)))
                {
                    DataContractJsonSerializer deserializer = new DataContractJsonSerializer(typeof(RootObject));
                    rootObject = (RootObject)deserializer.ReadObject(ms);
                }
            }
            return rootObject;
        }
    }
}
