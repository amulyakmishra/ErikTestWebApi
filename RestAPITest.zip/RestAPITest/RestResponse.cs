﻿using System.Collections.Generic;

namespace RestAPITest
{
    public class RestResponse
    {
        public List<string> messages { get; set; }
        public List<Result> result { get; set; }
    }
}
